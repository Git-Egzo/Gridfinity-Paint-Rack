import adsk.core
import adsk.fusion
import traceback
import math
import os

app = adsk.core.Application.get()
ui  = app.userInterface

BIN_BASE_TOP_SECTION_HEIGHT    = 0.215
BIN_BASE_MID_SECTION_HEIGHT    = 0.18
BIN_BASE_BOTTOM_SECTION_HEIGHT = 0.07
BIN_BASE_HEIGHT = (BIN_BASE_TOP_SECTION_HEIGHT +
                   BIN_BASE_MID_SECTION_HEIGHT +
                   BIN_BASE_BOTTOM_SECTION_HEIGHT)
BASE_EXTRA  = 1.88
GRID        = 4.2
GF_CORNER_R = 0.32
GF_CLEARANCE= 0.025
MAG_OFFSET  = 0.8
FILLET_R    = 0.3
MIN_SPACING = 0.2
EDGE_MARGIN = 0.5

BRANDS = [
    ('brand_artfly',  'Artfly ø34',  3.4),
    ('brand_vallejo', 'Vallejo ø25', 2.5),
    ('brand_citadel', 'Citadel ø27', 2.7),
]

_btn_id   = 'paintRackCmd'
_panel_id = 'SolidCreatePanel'

handlers = []

def rv(v):
    return adsk.core.ValueInput.createByReal(v)

def calc_positions(n, span, hole_d):
    if n <= 0:
        return []
    margin = hole_d / 2 + EDGE_MARGIN
    usable = span - 2 * margin
    if usable < 0:
        return None
    if n == 1:
        return [span / 2]
    pitch = usable / (n - 1)
    if pitch < hole_d + MIN_SPACING:
        return None
    return [margin + i * pitch for i in range(n)]

def _get_stair_depth(inputs):
    if inputs.itemById('custom_depth').value:
        return inputs.itemById('stair_depth').value
    return GRID

def _update_info(inputs):
    try:
        cols_gf       = inputs.itemById('cols').value
        rows          = inputs.itemById('rows').value
        hole_d        = inputs.itemById('hole_d').value
        hole_depth    = inputs.itemById('hole_depth').value
        holes_per_row = inputs.itemById('holes_per_row').value
        stair_depth   = _get_stair_depth(inputs)

        total_D   = rows * stair_depth
        gf_rows   = math.ceil(total_D / GRID)
        gf_D      = gf_rows * GRID
        back_fill = gf_D - total_D

        x_positions = calc_positions(holes_per_row, cols_gf * GRID, hole_d)

        lines = []
        if x_positions is None:
            lines.append("No space — reduce holes or diameter")
        else:
            total   = holes_per_row * rows
            spacing = (x_positions[1] - x_positions[0]) * 10 if len(x_positions) > 1 else 0
            lines.append(f"Total bottles: {total}  ({holes_per_row}/stair)")
            lines.append(f"Spacing: {spacing:.1f}mm  Edge: {x_positions[0]*10:.1f}mm")

        available = BIN_BASE_HEIGHT + BASE_EXTRA
        d_ok = hole_depth <= available - 0.05
        lines.append(f"Max depth: {available*10:.1f}mm  "
                     f"Hole: {hole_depth*10:.1f}mm  {'✓' if d_ok else '✗ TOO DEEP'}")
        if back_fill > 0.001:
            lines.append(f"Back fill: +{back_fill*10:.1f}mm → {gf_rows} GF rows")

        inputs.itemById('info').text = '\n'.join(lines)
    except:
        pass

# ══════════════════════════════════════════════════════════════════════
# ADD-IN ENTRY POINTS
# ══════════════════════════════════════════════════════════════════════

def run(context):
    global handlers
    handlers = []
    try:
        old = ui.commandDefinitions.itemById(_btn_id)
        if old:
            old.deleteMe()

        cmdDef = ui.commandDefinitions.addButtonDefinition(
            _btn_id,
            'Gridfinity Paint Rack',
            'Generates a Gridfinity paint bottle rack',
            '')

        onCreated = CommandCreatedHandler()
        cmdDef.commandCreated.add(onCreated)
        handlers.append(onCreated)

        panel = ui.allToolbarPanels.itemById(_panel_id)
        if panel:
            panel.controls.addCommand(cmdDef)

    except:
        ui.messageBox(traceback.format_exc())


def stop(context):
    try:
        panel = ui.allToolbarPanels.itemById(_panel_id)
        if panel:
            ctrl = panel.controls.itemById(_btn_id)
            if ctrl:
                ctrl.deleteMe()
        cmdDef = ui.commandDefinitions.itemById(_btn_id)
        if cmdDef:
            cmdDef.deleteMe()
    except:
        pass

# ══════════════════════════════════════════════════════════════════════
# HANDLERS
# ══════════════════════════════════════════════════════════════════════

class CommandCreatedHandler(adsk.core.CommandCreatedEventHandler):
    def notify(self, args):
        cmd    = args.command
        inputs = cmd.commandInputs

        inputs.addIntegerSpinnerCommandInput('cols', 'GF columns', 1, 20, 1, 6)
        inputs.addIntegerSpinnerCommandInput('rows', 'Stairs',     1, 20, 1, 2)
        inputs.addValueInput('step_h', 'Step height (mm)', 'mm', rv(2.0))

        inputs.addBoolValueInput('custom_depth', 'Custom stair depth', False)
        sd = inputs.addValueInput('stair_depth', 'Stair depth (mm)', 'mm', rv(4.2))
        sd.isEnabled = False

        for bid, label, _ in BRANDS:
            inputs.addBoolValueInput(bid, label, False)

        inputs.addValueInput('hole_d',     'Hole diam (mm)',  'mm', rv(3.4))
        inputs.addValueInput('hole_depth', 'Hole depth (mm)', 'mm', rv(2.0))
        inputs.addIntegerSpinnerCommandInput('holes_per_row', 'Holes/stair', 1, 200, 1, 6)

        inputs.addTextBoxCommandInput('info', 'Info', '–', 4, True)

        inputs.addBoolValueInput('magnets', 'Magnets', True)
        mag_d     = inputs.addValueInput('mag_d',     'Magnet diam (mm)',  'mm', rv(0.6))
        mag_depth = inputs.addValueInput('mag_depth', 'Magnet depth (mm)', 'mm', rv(0.2))

        inputs.addBoolValueInput('fillet', 'Round edges', True)

        onExecute      = CommandExecuteHandler()
        onInputChanged = InputChangedHandler()
        cmd.execute.add(onExecute)
        cmd.inputChanged.add(onInputChanged)
        handlers.append(onExecute)
        handlers.append(onInputChanged)

        _update_info(inputs)


class InputChangedHandler(adsk.core.InputChangedEventHandler):
    def notify(self, args):
        inputs  = args.inputs
        changed = args.input

        if changed.id == 'custom_depth':
            inputs.itemById('stair_depth').isEnabled = changed.value

        if changed.id == 'magnets':
            inputs.itemById('mag_d').isEnabled     = changed.value
            inputs.itemById('mag_depth').isEnabled = changed.value

        clicked = next((b for b in BRANDS if b[0] == changed.id and changed.value), None)
        if clicked:
            for bid, _, diam in BRANDS:
                if bid != clicked[0]:
                    inputs.itemById(bid).value = False
            inputs.itemById('hole_d').value = clicked[2]
        elif changed.id == 'hole_d':
            for bid, _, _ in BRANDS:
                inputs.itemById(bid).value = False

        _update_info(inputs)


class CommandExecuteHandler(adsk.core.CommandEventHandler):
    def notify(self, args):
        logPath = os.path.join(os.path.expanduser("~"), "Desktop", "paintRack_debug.log")
        log = open(logPath, "w", encoding="utf-8")
        def L(msg):
            log.write(msg + "\n")
            log.flush()

        try:
            L("START")
            design  = app.activeProduct
            root    = design.rootComponent
            inputs  = args.command.commandInputs

            COLS          = inputs.itemById('cols').value
            rows          = inputs.itemById('rows').value
            STEP          = inputs.itemById('step_h').value
            HOLE_D        = inputs.itemById('hole_d').value
            HOLE_DEPTH    = inputs.itemById('hole_depth').value
            holes_per_row = inputs.itemById('holes_per_row').value
            magnets       = inputs.itemById('magnets').value
            MAG_D         = inputs.itemById('mag_d').value
            MAG_DEPTH     = inputs.itemById('mag_depth').value
            do_fillet     = inputs.itemById('fillet').value
            STAIR_DEPTH   = _get_stair_depth(inputs)

            W         = COLS * GRID
            total_D   = rows * STAIR_DEPTH
            gf_rows   = math.ceil(total_D / GRID)
            gf_D      = gf_rows * GRID
            back_fill = gf_D - total_D

            x_positions = calc_positions(holes_per_row, W, HOLE_D)
            if x_positions is None:
                ui.messageBox("No space for holes — reduce count or diameter.")
                return

            y_offsets = calc_positions(1, STAIR_DEPTH, HOLE_D)
            if y_offsets is None:
                y_offsets = [STAIR_DEPTH / 2]

            L(f"cols={COLS} rows={rows} stair_depth={STAIR_DEPTH*10:.1f}mm "
              f"step={STEP*10:.1f}mm hole_d={HOLE_D*10:.1f}mm holes={holes_per_row} "
              f"back_fill={back_fill*10:.1f}mm gf_rows={gf_rows} "
              f"mag_d={MAG_D*10:.1f}mm mag_depth={MAG_DEPTH*10:.1f}mm")

            features = root.features
            extrudes = features.extrudeFeatures
            sketches = root.sketches
            NEG  = adsk.fusion.ExtentDirections.NegativeExtentDirection
            POS  = adsk.fusion.ExtentDirections.PositiveExtentDirection
            JOIN = adsk.fusion.FeatureOperations.JoinFeatureOperation
            NEW  = adsk.fusion.FeatureOperations.NewBodyFeatureOperation
            CUT  = adsk.fusion.FeatureOperations.CutFeatureOperation

            # ══════════════════════════════════════════════════════════
            # 1️⃣  SCHODKI
            # ══════════════════════════════════════════════════════════
            L("1 Stairs")
            stairPlaneIn = root.constructionPlanes.createInput()
            stairPlaneIn.setByOffset(root.xYConstructionPlane, rv(BIN_BASE_HEIGHT))
            stairPlane = root.constructionPlanes.add(stairPlaneIn)

            rackBody = None
            for row in range(rows):
                sk = sketches.add(stairPlane)
                y0 = row * STAIR_DEPTH
                y1 = (y0 + STAIR_DEPTH) if row < rows - 1 else gf_D
                sk.sketchCurves.sketchLines.addTwoPointRectangle(
                    adsk.core.Point3D.create(0, y0, 0),
                    adsk.core.Point3D.create(W, y1, 0))
                h = BASE_EXTRA + row * STEP
                if rackBody is None:
                    feat = extrudes.createInput(sk.profiles.item(0), NEW)
                    feat.setOneSideExtent(
                        adsk.fusion.DistanceExtentDefinition.create(rv(h)), POS, rv(0))
                    rackBody = extrudes.add(feat).bodies.item(0)
                else:
                    ei = extrudes.createInput(sk.profiles.item(0), JOIN)
                    ei.setOneSideExtent(
                        adsk.fusion.DistanceExtentDefinition.create(rv(h)), POS, rv(0))
                    extrudes.add(ei)
                L(f"  row={row} h={h*10:.1f}mm y0={y0*10:.1f} y1={y1*10:.1f}")

            # ══════════════════════════════════════════════════════════
            # 2️⃣  OTWORY
            # ══════════════════════════════════════════════════════════
            L("2 Holes")
            for row in range(rows):
                stair_h       = BASE_EXTRA + row * STEP
                total_depth   = BIN_BASE_HEIGHT + stair_h
                hole_d_actual = min(HOLE_DEPTH, total_depth - 0.05)
                zTop          = BIN_BASE_HEIGHT + stair_h

                plIn = root.constructionPlanes.createInput()
                plIn.setByOffset(root.xYConstructionPlane, rv(zTop))
                plane = root.constructionPlanes.add(plIn)
                skH   = sketches.add(plane)

                for x in x_positions:
                    for y_off in y_offsets:
                        y = row * STAIR_DEPTH + y_off
                        skH.sketchCurves.sketchCircles.addByCenterRadius(
                            adsk.core.Point3D.create(x, y, 0), HOLE_D / 2)

                for prof in skH.profiles:
                    ei2 = extrudes.createInput(prof, CUT)
                    ei2.participantBodies = [rackBody]
                    ei2.setOneSideExtent(
                        adsk.fusion.DistanceExtentDefinition.create(rv(hole_d_actual)),
                        NEG, rv(0))
                    extrudes.add(ei2)
                L(f"  row={row} depth={hole_d_actual*10:.1f}mm")

            # ══════════════════════════════════════════════════════════
            # 3️⃣  FILLET
            # ══════════════════════════════════════════════════════════
            if do_fillet:
                L("3 Fillet")
                edgesF = adsk.core.ObjectCollection.create()
                tol    = 0.001
                step_tops = [BIN_BASE_HEIGHT + BASE_EXTRA + r * STEP for r in range(rows)]

                def on_outer_x(x):
                    return abs(x) < tol or abs(x - W) < tol
                def on_any_y(y):
                    boundaries = [r * STAIR_DEPTH for r in range(rows)] + [gf_D]
                    return any(abs(y - b) < tol for b in boundaries)
                def on_outer_z(z):
                    return any(abs(z - oz) < tol for oz in step_tops)

                for edge in rackBody.edges:
                    try:
                        if edge.geometry.curveType != adsk.core.Curve3DTypes.Line3DCurveType:
                            continue
                        if edge.faces.count != 2:
                            continue
                        p1 = edge.startVertex.geometry
                        p2 = edge.endVertex.geometry
                        x1,y1,z1 = p1.x,p1.y,p1.z
                        x2,y2,z2 = p2.x,p2.y,p2.z
                        dx=abs(x1-x2); dy=abs(y1-y2); dz=abs(z1-z2)
                        add = False
                        if dz>tol and dx<tol and dy<tol:
                            if on_outer_x(x1) and on_any_y(y1):
                                add = True
                        elif dx>tol and dy<tol and dz<tol:
                            if on_outer_z(z1):
                                is_concave = any(
                                    abs(y1 - r*STAIR_DEPTH) < tol and
                                    abs(z1 - step_tops[r-1]) < tol
                                    for r in range(1, rows))
                                if not is_concave:
                                    add = True
                        elif dy>tol and dx<tol and dz<tol:
                            if on_outer_x(x1) and on_outer_z(z1):
                                add = True
                        if add:
                            edgesF.add(edge)
                    except:
                        pass

                L(f"  edges={edgesF.count}")
                if edgesF.count > 0:
                    fi = features.filletFeatures.createInput()
                    fi.addConstantRadiusEdgeSet(edgesF, rv(FILLET_R), True)
                    features.filletFeatures.add(fi)

            # ══════════════════════════════════════════════════════════
            # 4️⃣  GF CELL
            # ══════════════════════════════════════════════════════════
            L("4 GF cell")
            cellW   = GRID - 2 * GF_CLEARANCE
            originX = GF_CLEARANCE
            originY = GF_CLEARANCE

            basePlaneIn = root.constructionPlanes.createInput()
            basePlaneIn.setByOffset(root.xYConstructionPlane, rv(BIN_BASE_HEIGHT))
            basePlane = root.constructionPlanes.add(basePlaneIn)

            skCell = sketches.add(basePlane)
            skCell.sketchCurves.sketchLines.addTwoPointRectangle(
                adsk.core.Point3D.create(originX,         originY,         0),
                adsk.core.Point3D.create(originX + cellW, originY + cellW, 0))

            topExtIn = extrudes.createInput(skCell.profiles.item(0), NEW)
            topExtIn.setOneSideExtent(
                adsk.fusion.DistanceExtentDefinition.create(rv(BIN_BASE_TOP_SECTION_HEIGHT)),
                NEG, rv(0))
            topExt   = extrudes.add(topExtIn)
            baseBody = topExt.bodies.item(0)

            fillEdges = adsk.core.ObjectCollection.create()
            for edge in baseBody.edges:
                try:
                    p1 = edge.startVertex.geometry
                    p2 = edge.endVertex.geometry
                    if (abs(p1.x-p2.x)<0.0001 and abs(p1.y-p2.y)<0.0001 and
                            abs(p1.distanceTo(p2)-BIN_BASE_TOP_SECTION_HEIGHT)<0.001):
                        fillEdges.add(edge)
                except: pass
            if fillEdges.count > 0:
                fi2 = features.filletFeatures.createInput()
                fi2.isRollingBallCorner = True
                fi2.edgeSetInputs.addConstantRadiusEdgeSet(fillEdges, rv(GF_CORNER_R), True)
                features.filletFeatures.add(fi2)

            chIn = features.chamferFeatures.createInput2()
            chE  = adsk.core.ObjectCollection.create()
            chE.add(topExt.endFaces.item(0).edges.item(0))
            chIn.chamferEdgeSets.addEqualDistanceChamferEdgeSet(
                chE, rv(BIN_BASE_TOP_SECTION_HEIGHT), True)
            features.chamferFeatures.add(chIn)

            midBotIn = extrudes.createInput(topExt.endFaces.item(0), JOIN)
            midBotIn.participantBodies = [baseBody]
            midBotIn.setOneSideExtent(
                adsk.fusion.DistanceExtentDefinition.create(
                    rv(BIN_BASE_MID_SECTION_HEIGHT + BIN_BASE_BOTTOM_SECTION_HEIGHT)),
                POS, rv(0))
            midBotExt = extrudes.add(midBotIn)

            chIn2 = features.chamferFeatures.createInput2()
            botE  = adsk.core.ObjectCollection.create()
            for edge in midBotExt.endFaces.item(0).edges:
                botE.add(edge)
            chIn2.chamferEdgeSets.addEqualDistanceChamferEdgeSet(
                botE, rv(BIN_BASE_BOTTOM_SECTION_HEIGHT), True)
            features.chamferFeatures.add(chIn2)

            # ══════════════════════════════════════════════════════════
            # 5️⃣  MAGNESY
            # ══════════════════════════════════════════════════════════
            if magnets:
                L("5 Magnets")
                skMag = sketches.add(root.xYConstructionPlane)
                skMag.sketchCurves.sketchCircles.addByCenterRadius(
                    adsk.core.Point3D.create(originX + MAG_OFFSET, originY + MAG_OFFSET, 0),
                    MAG_D / 2)
                magExtIn = extrudes.createInput(skMag.profiles.item(0), NEW)
                magExtIn.setOneSideExtent(
                    adsk.fusion.DistanceExtentDefinition.create(rv(MAG_DEPTH)), POS, rv(0))
                magBody = extrudes.add(magExtIn).bodies.item(0)

                midXZIn = root.constructionPlanes.createInput()
                midXZIn.setByOffset(root.xZConstructionPlane, rv(originY + cellW / 2))
                midXZ = root.constructionPlanes.add(midXZIn)
                midYZIn = root.constructionPlanes.createInput()
                midYZIn.setByOffset(root.yZConstructionPlane, rv(originX + cellW / 2))
                midYZ = root.constructionPlanes.add(midYZIn)
                axisIn = root.constructionAxes.createInput()
                axisIn.setByTwoPlanes(midXZ, midYZ)
                centerAxis = root.constructionAxes.add(axisIn)

                magBodies = adsk.core.ObjectCollection.create()
                magBodies.add(magBody)
                cpIn = features.circularPatternFeatures.createInput(magBodies, centerAxis)
                cpIn.quantity = adsk.core.ValueInput.createByString("4")
                magPat = features.circularPatternFeatures.add(cpIn)

                allMag = adsk.core.ObjectCollection.create()
                allMag.add(magBody)
                for b in magPat.bodies:
                    allMag.add(b)
                cutIn = features.combineFeatures.createInput(baseBody, allMag)
                cutIn.operation = CUT
                cutIn.isKeepToolBodies = False
                features.combineFeatures.add(cutIn)

            # ══════════════════════════════════════════════════════════
            # 6️⃣  GF PATTERN
            # ══════════════════════════════════════════════════════════
            L("6 GF Pattern")
            patB = adsk.core.ObjectCollection.create()
            patB.add(baseBody)
            pIn = features.rectangularPatternFeatures.createInput(
                patB, root.xConstructionAxis,
                rv(COLS), rv(GRID),
                adsk.fusion.PatternDistanceType.SpacingPatternDistanceType)
            pIn.directionTwoEntity = root.yConstructionAxis
            pIn.quantityTwo        = rv(gf_rows)
            pIn.distanceTwo        = rv(GRID)
            features.rectangularPatternFeatures.add(pIn)
            L(f"  gf_rows={gf_rows}  total bodies={root.bRepBodies.count}")
            L("DONE ✓")

        except Exception as e:
            msg = traceback.format_exc()
            log.write("\n\nEXCEPTION:\n" + msg)
            ui.messageBox(msg)
        finally:
            log.close()
